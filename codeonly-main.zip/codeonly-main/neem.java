public class neem {
public static void show(){
    System.out.println("wowowowo");
}
void display(){
    System.out.println("womp womp");
}
}
