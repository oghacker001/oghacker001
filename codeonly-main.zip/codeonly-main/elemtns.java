public class elemtns {
    public static void main(String[] args) {
     int i = 0;
     do{
        i++;
        System.out.println(args[i]);
     }   while (i<args.length);
     
    }

}
