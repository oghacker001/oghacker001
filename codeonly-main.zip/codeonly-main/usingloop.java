public class usingloop {
    public static void main(String[] args) {
        //aray declairation
        int arr[];
        String str[];
        //aray construction
        arr = new int[3];
        str = new String[3];
        //array intialization
        arr[0] = 10;
        arr[2] = 20;
        str[0] = "java";
        str[2] = "asit";
        
        for (int i=0;i<arr.length;i++){
            System.out.println(arr[i] +"   ");
            
            
        }
        for (int i=0;i<str.length;i++){
            System.out.println(str[i] +"   ");
    }
    
}
}
    