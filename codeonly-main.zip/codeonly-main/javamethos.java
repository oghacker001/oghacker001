
public class javamethos {
    public static void main(String[] args) {
        new javamethos().add();
        int x=new javamethos().sum();
        System.out.println("sum is "+x);
    }
public void add(){
    int num1=100;
    int num2=20;
    System.out.println("sum is " +(num1+num2));
}
public int sum(){
    int num1=10;
    int num2=20;
    int sum=num1+num2;
    return sum;
}
}
