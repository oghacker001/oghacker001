
public class newk {
    public static void main(String[] args) {
       String name="asit garabadu";
        String address="linipur samantarapur";
        System.out.println(name);
        System.out.println(address);

    }

}
